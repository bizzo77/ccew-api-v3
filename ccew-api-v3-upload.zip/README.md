# CCEW API v3

CCEW (Certificate of Compliance for Electrical Work) form generation API for Proform Electrical.

## Overview

This API integrates with SimPro job management software to automatically generate and pre-fill CCEW forms when electrical jobs are completed.

## Features

- **Auto-fill from SimPro**: Reads job data and custom fields from SimPro API
- **Custom Fields Integration**: Uses 13 custom fields for technician license, installation address, and customer details
- **Mobile-friendly Form**: Technicians complete remaining fields on mobile device
- **Session Management**: Secure session-based form handling

## Endpoints

### `GET /`
Health check endpoint
- Returns API status and version information

### `POST /api/ccew/generate`
Generate a new CCEW form session from SimPro job data
- **Input**: SimPro job data with custom fields
- **Output**: Session ID and form URL

### `GET /form/<session_id>`
Display the CCEW form with pre-filled fields
- **Input**: Session ID
- **Output**: HTML form with pre-filled AUTO/HARDCODE fields and editable MOBILE fields

### `POST /api/ccew/submit`
Submit completed CCEW form
- **Input**: Form data from technician
- **Output**: Success confirmation

## Custom Fields Required in SimPro

The API expects these 13 custom fields in SimPro job data:

**Technician (2 fields):**
- Tech Licence Number
- Tech License Expiry

**Installation Address (4 fields):**
- Install Street Number
- Install Street Name
- Install Suburb
- Install Postcode

**Customer Name (2 fields):**
- Customer First Name
- Customer Last Name

**Customer Address (5 fields):**
- Customer Street Number
- Customer Street Name
- Customer Suburb
- Customer State
- Customer Postcode

## Deployment

### Requirements
- Python 3.11+
- Flask 3.0.0
- ReportLab 4.0.7

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Run Locally
```bash
python app.py
```

The API will run on `http://localhost:5000`

### Deploy to Render
1. Push code to GitHub
2. Create new Web Service on Render
3. Connect to this repository
4. Use these settings:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`

## Integration with Make.com

This API is designed to work with Make.com automation scenarios:

1. SimPro webhook triggers when job is completed
2. Make.com scenario extracts job data and custom fields
3. Make.com calls `/api/ccew/generate` endpoint
4. API returns form URL
5. Make.com sends SMS with form URL to technician
6. Technician completes form on mobile
7. Form submits to `/api/ccew/submit`
8. PDF generated and emailed to energy supplier

## Version History

### v3.0.1 (Current)
- Added custom fields integration
- Reads 13 custom fields from SimPro job data
- Maps fields to CCEW form template
- Improved error handling

### v3.0.0
- Initial version with basic form generation
- Auto-fill and hardcode field support
- Mobile form with editable fields

## License

Proprietary - Proform Electrical

